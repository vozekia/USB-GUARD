<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->
- The native Android app lives in android/ (Gradle, built by .github/workflows/android-apk.yml); keep it independent from the web app because Lovable cannot build Android.
- The Windows app lives in windows/ (.NET 8 WPF, built by .github/workflows/windows-build.yml); keep it independent from the web app.
