# USB Guard — Android (MVP)

Aplicativo nativo em Kotlin. Sem root, sem internet, não apaga nem desinstala nada.

## Montar
- **GitHub Actions:** o workflow `.github/workflows/android-apk.yml` roda os testes e gera `USBGuard-debug-apk` (aba Actions → execução → Artifacts).
- **Android Studio:** File → Open → pasta `android/`. Requer JDK 17. Rodar `gradle :app:assembleDebug`.

## Limitações
- No Android 11+ só enxerga apps com ícone na tela inicial (declaração `<queries>`). Apps de sistema são ignorados.
- A classificação usa indicadores (sobreposição de tela, acessibilidade, administrador, origem da instalação, instalação recente). Não prova que um app é malicioso.
- APK de depuração, sem assinatura oficial.
