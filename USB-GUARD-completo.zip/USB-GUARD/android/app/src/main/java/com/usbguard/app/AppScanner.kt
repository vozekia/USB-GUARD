package com.usbguard.app

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build

class AppScanner(private val context: Context) {

    data class ScanOutput(val results: List<AppResult>, val systemSkipped: Int)

    /** Examina somente os apps que o Android deixa este app enxergar. */
    fun scan(): ScanOutput {
        val pm = context.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        @Suppress("DEPRECATION")
        val packages = pm.queryIntentActivities(launcher, 0)
            .map { it.activityInfo.packageName }
            .distinct()
            .filter { it != context.packageName }

        val now = System.currentTimeMillis()
        var systemSkipped = 0
        val results = mutableListOf<AppResult>()
        for (pkg in packages) {
            val facts = try {
                @Suppress("DEPRECATION")
                val info = pm.getPackageInfo(pkg, PackageManager.GET_PERMISSIONS)
                val appInfo = info.applicationInfo
                if (appInfo != null && (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0 &&
                    (appInfo.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0) {
                    systemSkipped++
                    continue
                }
                AppFacts(
                    packageName = pkg,
                    label = appInfo?.loadLabel(pm)?.toString() ?: pkg,
                    permissions = info.requestedPermissions?.toSet() ?: emptySet(),
                    installer = installerOf(pm, pkg),
                    installedDaysAgo = (now - info.firstInstallTime) / DAY,
                    updatedDaysAgo = (now - info.lastUpdateTime) / DAY
                )
            } catch (e: Exception) {
                AppFacts(pkg, pkg, null, null, null, null)
            }
            results += RiskClassifier.classify(facts)
        }
        return ScanOutput(results.sortedByDescending { it.level.ordinalRisk() }, systemSkipped)
    }

    private fun installerOf(pm: PackageManager, pkg: String): String? = try {
        if (Build.VERSION.SDK_INT >= 30) pm.getInstallSourceInfo(pkg).installingPackageName
        else @Suppress("DEPRECATION") pm.getInstallerPackageName(pkg)
    } catch (e: Exception) { null }

    companion object { private const val DAY = 24L * 60 * 60 * 1000 }
}

fun RiskLevel.ordinalRisk(): Int = when (this) {
    RiskLevel.ALTO_RISCO -> 4
    RiskLevel.SUSPEITO -> 3
    RiskLevel.ATENCAO -> 2
    RiskLevel.NAO_DETERMINADO -> 1
    RiskLevel.NORMAL -> 0
}
