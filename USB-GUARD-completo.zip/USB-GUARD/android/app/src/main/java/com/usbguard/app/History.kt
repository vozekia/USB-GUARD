package com.usbguard.app

import android.content.Context

/** Histórico guardado só no aparelho (SharedPreferences). Máximo de 20 itens. */
object History {
    data class Entry(val time: Long, val text: String)
    private const val KEY = "entries"

    fun save(ctx: Context, total: Int, counts: Map<RiskLevel, Int>) {
        val line = "${System.currentTimeMillis()}|$total apps; " +
            counts.entries.joinToString(", ") { "${it.key.label} ${it.value}" }
        val prefs = ctx.getSharedPreferences("history", Context.MODE_PRIVATE)
        val all = (listOf(line) + (prefs.getString(KEY, "") ?: "").split("\n").filter { it.isNotBlank() }).take(20)
        prefs.edit().putString(KEY, all.joinToString("\n")).apply()
    }

    fun load(ctx: Context): List<Entry> =
        (ctx.getSharedPreferences("history", Context.MODE_PRIVATE).getString(KEY, "") ?: "")
            .split("\n").filter { it.contains("|") }
            .map { Entry(it.substringBefore("|").toLong(), it.substringAfter("|")) }
}
