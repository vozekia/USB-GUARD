package com.usbguard.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {

    private lateinit var list: LinearLayout
    private lateinit var summary: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 60, 40, 40) }
        root.addView(text("USB Guard", 28f, bold = true))
        root.addView(text("Verifica os aplicativos que o Android permite consultar. Nada é apagado e nenhum dado sai do celular.", 14f))

        root.addView(Button(this).apply {
            text = "Verificar aplicativos"
            setOnClickListener { runScan() }
        })
        root.addView(Button(this).apply {
            text = "Histórico"
            setOnClickListener { showHistory() }
        })

        summary = text("", 15f, bold = true)
        root.addView(summary)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(list)

        root.addView(text(
            "Limitações: o USB Guard não usa root, não remove apps e não garante proteção total. " +
            "No Android 11 ou mais novo, só enxerga apps que aparecem na tela inicial; apps ocultos e de sistema não são examinados. " +
            "Um alerta indica pontos para conferir, não prova que o app é um vírus.", 12f))

        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun runScan() {
        list.removeAllViews()
        summary.text = "Verificando…"
        Thread {
            val out = AppScanner(this).scan()
            runOnUiThread { showResults(out) }
        }.start()
    }

    private fun showResults(out: AppScanner.ScanOutput) {
        val counts = RiskLevel.values().associateWith { lvl -> out.results.count { it.level == lvl } }
        summary.text = "${out.results.size} apps examinados (${out.systemSkipped} apps de sistema ignorados).\n" +
            counts.entries.joinToString("  ") { "${it.key.label}: ${it.value}" }
        History.save(this, out.results.size, counts)

        for (r in out.results) {
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(24, 24, 24, 24)
                setBackgroundColor(colorFor(r.level))
            }
            card.addView(text("${r.facts.label} — ${r.level.label}", 15f, bold = true))
            card.addView(text(r.facts.packageName, 11f))
            r.reasons.forEach { card.addView(text("• $it", 13f)) }
            if (r.level != RiskLevel.NORMAL) {
                card.addView(Button(this).apply {
                    text = "Abrir detalhes do app (você decide)"
                    setOnClickListener {
                        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                            Uri.parse("package:${r.facts.packageName}")))
                    }
                })
            }
            list.addView(card)
            list.addView(View(this).apply { minimumHeight = 16 })
        }
    }

    private fun showHistory() {
        list.removeAllViews()
        val entries = History.load(this)
        summary.text = if (entries.isEmpty()) "Nenhuma verificação ainda." else "Histórico (salvo só neste celular):"
        val fmt = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("pt", "BR"))
        entries.forEach { e -> list.addView(text("${fmt.format(Date(e.time))} — ${e.text}", 13f)) }
    }

    private fun colorFor(l: RiskLevel) = when (l) {
        RiskLevel.NORMAL -> Color.rgb(225, 245, 230)
        RiskLevel.ATENCAO -> Color.rgb(255, 245, 205)
        RiskLevel.SUSPEITO -> Color.rgb(255, 225, 195)
        RiskLevel.ALTO_RISCO -> Color.rgb(255, 210, 210)
        RiskLevel.NAO_DETERMINADO -> Color.rgb(230, 230, 235)
    }

    private fun text(s: String, size: Float, bold: Boolean = false) = TextView(this).apply {
        text = s; textSize = size; setPadding(0, 8, 0, 8)
        setTextColor(Color.rgb(20, 20, 30))
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }
}
