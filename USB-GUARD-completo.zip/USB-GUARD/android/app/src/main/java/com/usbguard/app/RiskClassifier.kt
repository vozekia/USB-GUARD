package com.usbguard.app

enum class RiskLevel(val label: String) {
    NORMAL("NORMAL"),
    ATENCAO("ATENÇÃO"),
    SUSPEITO("SUSPEITO"),
    ALTO_RISCO("ALTO RISCO"),
    NAO_DETERMINADO("NÃO DETERMINADO")
}

/** Dados que o Android permite ler sobre um app. Tudo vem do próprio aparelho. */
data class AppFacts(
    val packageName: String,
    val label: String,
    val permissions: Set<String>?,      // null = não foi possível ler
    val installer: String?,             // null = origem desconhecida
    val installedDaysAgo: Long?,
    val updatedDaysAgo: Long?
)

data class AppResult(val facts: AppFacts, val level: RiskLevel, val reasons: List<String>)

object RiskClassifier {
    const val OVERLAY = "android.permission.SYSTEM_ALERT_WINDOW"
    const val INSTALL = "android.permission.REQUEST_INSTALL_PACKAGES"
    const val BOOT = "android.permission.RECEIVE_BOOT_COMPLETED"
    const val ACCESSIBILITY = "android.permission.BIND_ACCESSIBILITY_SERVICE"
    const val DEVICE_ADMIN = "android.permission.BIND_DEVICE_ADMIN"

    private val trustedStores = setOf(
        "com.android.vending", "com.google.android.packageinstaller",
        "com.sec.android.app.samsungapps", "com.huawei.appmarket",
        "com.xiaomi.market", "com.amazon.venezia"
    )

    /**
     * Soma de indicadores transparentes. Nenhum indicador sozinho
     * leva a SUSPEITO: um app não é malicioso só por ser desconhecido.
     */
    fun classify(f: AppFacts): AppResult {
        val perms = f.permissions
            ?: return AppResult(f, RiskLevel.NAO_DETERMINADO,
                listOf("O Android não permitiu ler as permissões deste app."))

        val reasons = mutableListOf<String>()
        var score = 0

        if (OVERLAY in perms) {
            score += 2
            reasons += "Pode desenhar janelas por cima de outros apps (comum em propagandas que abrem telas sozinhas)."
        }
        if (ACCESSIBILITY in perms) {
            score += 2
            reasons += "Pede acesso de acessibilidade, que permite controlar a tela."
        }
        if (DEVICE_ADMIN in perms) {
            score += 2
            reasons += "Pede ser administrador do aparelho, o que dificulta a desinstalação."
        }
        if (INSTALL in perms) {
            score += 1
            reasons += "Pode pedir para instalar outros apps."
        }
        if (BOOT in perms && OVERLAY in perms) {
            score += 1
            reasons += "Inicia junto com o celular e pode abrir janelas por cima."
        }
        if (f.installer == null || f.installer !in trustedStores) {
            score += 1
            reasons += "Não foi instalado por uma loja oficial conhecida."
        }
        val recent = listOfNotNull(f.installedDaysAgo, f.updatedDaysAgo).minOrNull()
        if (recent != null && recent <= 7 && score > 0) {
            score += 1
            reasons += "Foi instalado ou atualizado nos últimos 7 dias — confira se as propagandas começaram nessa época."
        }

        val level = when {
            score >= 6 -> RiskLevel.ALTO_RISCO
            score >= 4 -> RiskLevel.SUSPEITO
            score >= 2 -> RiskLevel.ATENCAO
            else -> RiskLevel.NORMAL
        }
        if (reasons.isEmpty()) reasons += "Nenhum indicador de risco encontrado."
        return AppResult(f, level, reasons)
    }
}
