package com.usbguard.app

import org.junit.Assert.assertEquals
import org.junit.Test

class RiskClassifierTest {
    private fun facts(perms: Set<String>?, installer: String? = "com.android.vending", days: Long = 100) =
        AppFacts("x.y", "X", perms, installer, days, days)

    @Test fun plainStoreAppIsNormal() =
        assertEquals(RiskLevel.NORMAL, RiskClassifier.classify(facts(emptySet())).level)

    @Test fun unknownSourceAloneIsNotSuspicious() =
        assertEquals(RiskLevel.NORMAL, RiskClassifier.classify(facts(emptySet(), installer = null)).level)

    @Test fun unreadablePermissionsIsUndetermined() =
        assertEquals(RiskLevel.NAO_DETERMINADO, RiskClassifier.classify(facts(null)).level)

    @Test fun overlayFromStoreIsAttention() =
        assertEquals(RiskLevel.ATENCAO, RiskClassifier.classify(facts(setOf(RiskClassifier.OVERLAY))).level)

    @Test fun overlayAccessibilityUnknownSourceIsSuspicious() =
        assertEquals(RiskLevel.SUSPEITO, RiskClassifier.classify(
            facts(setOf(RiskClassifier.OVERLAY, RiskClassifier.ACCESSIBILITY), installer = null)).level)

    @Test fun manyIndicatorsRecentIsHighRisk() =
        assertEquals(RiskLevel.ALTO_RISCO, RiskClassifier.classify(facts(
            setOf(RiskClassifier.OVERLAY, RiskClassifier.ACCESSIBILITY, RiskClassifier.BOOT),
            installer = null, days = 2)).level)
}
