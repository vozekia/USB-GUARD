# Roadmap
- [x] Painel no site com o status e as pendências dos downloads Android e Windows
- [x] Site do USB Guard (Android + Windows)
- [x] Projeto Android nativo MVP (Kotlin, testes, workflow GitHub Actions)
- [x] Sincronizar o painel do site com o estado real do projeto Android
- [ ] Conectar o projeto ao GitHub (aguarda o usuário: Configurações do projeto → Git → Connect)
- [ ] Compilar o APK no GitHub Actions (aguarda o usuário conectar o GitHub)
- [x] Workflow de compilação Windows (.github/workflows/windows-build.yml)
- [ ] Compilar o Windows no GitHub Actions (aguarda o usuário conectar o GitHub)
- [ ] Link de download real do app Windows (aguarda compilação e teste)
