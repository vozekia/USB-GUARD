import { createFileRoute } from "@tanstack/react-router";
import { CheckCircle2, CircleDashed, Clock3, Monitor, Smartphone } from "lucide-react";
import hero from "@/assets/hero.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "USB Guard — Antivírus e bloqueio de propagandas para Android e Windows" },
      { name: "description", content: "Remova vírus e pare propagandas que abrem várias telas no celular Android e no Windows." },
      { property: "og:title", content: "USB Guard — Proteção para Android e Windows" },
      { property: "og:description", content: "Diagnóstico seguro contra vírus e propagandas invasivas." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const features = [
  { t: "Encontra vírus e apps suspeitos", d: "Analisa processos, apps e itens que iniciam sozinhos com o aparelho." },
  { t: "Para propagandas invasivas", d: "Identifica o que abre várias telas e anúncios ao mesmo tempo." },
  { t: "Libera espaço com segurança", d: "Só aponta arquivos temporários antigos. Fotos, documentos e downloads ficam protegidos." },
  { t: "Você decide", d: "Nada é apagado sem sua confirmação." },
];

const steps = {
  Android: [
    "Abra Configurações > Apps e procure apps que você não instalou ou com nomes estranhos.",
    "Toque no app suspeito e escolha Desinstalar.",
    "Em Configurações > Apps > Acesso especial, desative \"Sobrepor a outros apps\" para apps desconhecidos.",
    "No navegador, bloqueie notificações de sites que mostram propagandas.",
    "Ative o Google Play Protect na Play Store.",
  ],
  Windows: [
    "Abra o Gerenciador de Tarefas (Ctrl+Shift+Esc) > Inicializar e desative itens desconhecidos.",
    "Em Configurações > Aplicativos, desinstale programas que você não reconhece.",
    "Execute uma verificação completa no Segurança do Windows.",
    "Redefina o navegador e remova extensões suspeitas.",
    "Rode o USB Guard para ver o diagnóstico completo.",
  ],
};

function Index() {
  return (
    <main className="min-h-screen bg-background font-sans text-foreground">
      <section className="mx-auto grid max-w-6xl items-center gap-10 px-6 py-16 md:grid-cols-2 md:py-24">
        <div>
          <p className="mb-4 text-sm font-semibold uppercase tracking-widest text-primary">USB Guard</p>
          <h1 className="font-display text-4xl font-bold leading-tight md:text-6xl">
            Chega de vírus e propagandas pulando na tela.
          </h1>
          <p className="mt-6 text-lg text-muted-foreground">
            Proteção para celular Android e computador Windows. Descubra o que está abrindo várias telas ao mesmo tempo e remova com segurança.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <a href="#download" className="rounded-lg bg-primary px-6 py-3 font-semibold text-primary-foreground shadow-glow transition hover:opacity-90">Baixar grátis</a>
            <a href="#guia" className="rounded-lg border border-border px-6 py-3 font-semibold transition hover:bg-secondary">Remover agora, passo a passo</a>
          </div>
        </div>
        <img src={hero} alt="Escudo protegendo celular e notebook" width={1280} height={896} className="rounded-2xl shadow-glow" />
      </section>

      <section className="mx-auto grid max-w-6xl gap-4 px-6 pb-16 sm:grid-cols-2 lg:grid-cols-4">
        {features.map((f) => (
          <div key={f.t} className="rounded-xl border border-border bg-card p-6">
            <h3 className="font-display text-lg font-semibold text-primary">{f.t}</h3>
            <p className="mt-2 text-sm text-muted-foreground">{f.d}</p>
          </div>
        ))}
      </section>

      <section id="guia" className="mx-auto max-w-6xl px-6 py-16">
        <h2 className="font-display text-3xl font-bold">Como tirar propagandas e vírus agora</h2>
        <div className="mt-8 grid gap-6 md:grid-cols-2">
          {Object.entries(steps).map(([os, list]) => (
            <div key={os} className="rounded-xl border border-border bg-card p-6">
              <h3 className="font-display text-xl font-semibold">{os}</h3>
              <ol className="mt-4 space-y-3">
                {list.map((s, i) => (
                  <li key={i} className="flex gap-3 text-muted-foreground">
                    <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-accent text-xs font-bold text-primary">{i + 1}</span>
                    {s}
                  </li>
                ))}
              </ol>
            </div>
          ))}
        </div>
      </section>

      <section id="download" className="mx-auto max-w-6xl px-6 py-16">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <h2 className="font-display text-3xl font-bold">Status dos downloads</h2>
          <span className="flex items-center gap-2 text-sm text-muted-foreground">
            <Clock3 className="h-4 w-4" aria-hidden="true" /> Sem data de lançamento definida
          </span>
        </div>
        <p className="mt-4 max-w-2xl text-muted-foreground">
          Os downloads ainda não estão disponíveis. Veja o que já recebemos e o que falta para liberar cada versão do USB Guard.
        </p>
        <div className="mt-8 grid gap-6 md:grid-cols-2">
          {[
            {
              os: "Android",
              icon: Smartphone,
              status: "Projeto Android existente — aguardando integração com GitHub e geração do APK",
              pending: "O aplicativo Android já está pronto nos arquivos do projeto. Falta conectar o projeto ao GitHub para o APK ser gerado automaticamente.",
              items: [
                { label: "Criar o projeto Android completo (código, configuração e testes)", done: true },
                { label: "Conectar o projeto ao GitHub", done: false },
                { label: "Compilar e gerar o APK de teste no GitHub Actions", done: false },
                { label: "Testar a instalação e o funcionamento no celular", done: false },
                { label: "Preparar a versão assinada e disponibilizar o link de download", done: false },
              ],
            },
            {
              os: "Windows 10 e 11",
              icon: Monitor,
              status: "Compilação automática preparada — aguardando integração com GitHub",
              pending: "Versão de diagnóstico: ainda não remove ameaças automaticamente. A compilação roda num computador Windows do GitHub assim que o projeto for conectado.",
              items: [
                { label: "Receber o projeto Windows", done: true },
                { label: "Preparar a compilação automática com .NET 8", done: true },
                { label: "Compilar e rodar os testes no GitHub Actions", done: false },
                { label: "Testar a instalação e o diagnóstico no computador", done: false },
                { label: "Disponibilizar o arquivo e o link de download", done: false },
              ],
            },
          ].map(({ os, icon: PlatformIcon, status, pending, items }) => (
            <article key={os} className="rounded-lg border border-border bg-card p-6">
              <div className="flex items-center gap-3">
                <PlatformIcon className="h-6 w-6 shrink-0 text-primary" aria-hidden="true" />
                <h3 className="font-display text-xl font-semibold">{os}</h3>
              </div>
              <p className="mt-4 flex items-start gap-2 text-sm font-semibold text-muted-foreground">
                <Clock3 className="mt-0.5 h-4 w-4 shrink-0" aria-hidden="true" /> {status}
              </p>
              <p className="mt-3 text-sm text-muted-foreground">{pending}</p>
              <ul className="mt-6 space-y-4 border-t border-border pt-6">
                {items.map(({ label, done }) => (
                  <li key={label} className="flex items-start gap-3 text-sm">
                    {done ? (
                      <CheckCircle2 className="h-5 w-5 shrink-0 text-primary" aria-hidden="true" />
                    ) : (
                      <CircleDashed className="h-5 w-5 shrink-0 text-muted-foreground" aria-hidden="true" />
                    )}
                    <span className={done ? "text-foreground" : "text-muted-foreground"}>
                      <span className="sr-only">{done ? "Concluído: " : "Pendente: "}</span>{label}
                    </span>
                  </li>
                ))}
              </ul>
              <p className="mt-6 border-t border-border pt-4 text-sm text-muted-foreground">
                {os === "Android"
                  ? "Projeto criado e verificado. APK ainda não gerado. Nenhum teste em celular realizado."
                  : "Projeto recebido: apenas diagnóstico; ainda não remove ameaças. Nenhum teste realizado."}
              </p>
            </article>
          ))}
        </div>
      </section>

      <footer className="border-t border-border py-8 text-center text-sm text-muted-foreground">
        USB Guard · Diagnóstico seguro: nada é apagado sem sua permissão.
      </footer>
    </main>
  );
}
