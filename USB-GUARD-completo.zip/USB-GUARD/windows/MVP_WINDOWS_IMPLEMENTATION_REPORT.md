# USB Guard Windows — Relatório da Fase 1

Data: 2026-10-12

## Implementação realizada

Foi criado um projeto separado em `/home/ubuntu/usb-guard/windows-mvp`, sem alterar o projeto Android existente nem a cópia de referência do APK.

A aplicação é WPF em C#/.NET 8 e é estritamente somente leitura. A janela executa uma coleta real quando o usuário solicita a análise. Ela exibe sistema operacional, computador, memória disponível/total obtida por `GlobalMemoryStatusEx`, uma amostra de CPU obtida por `GetSystemTimes`, discos, processos acessíveis, itens de inicialização consultáveis e candidatos encontrados em raízes temporárias.

A política de candidatos exige raiz temporária permitida, caminho dentro da raiz, ausência de reparse point/link/junção, arquivo regular, idade mínima de um dia e abertura somente para leitura. Caminhos pessoais, Downloads, documentos, projetos, backups, OneDrive e perfis de navegadores são protegidos. A política não chama operações de exclusão, movimentação, alteração, quarentena ou Registro de escrita.

## Arquivos criados

- `USBGuard.Windows.sln`
- `README.md`
- `UsbGuard.Windows/UsbGuard.Windows.csproj`
- `UsbGuard.Windows/App.xaml`
- `UsbGuard.Windows/App.xaml.cs`
- `UsbGuard.Windows/Models/DiagnosticModels.cs`
- `UsbGuard.Windows/Models/README.md`
- `UsbGuard.Windows/Services/TempCandidatePolicy.cs`
- `UsbGuard.Windows/Services/WindowsDiagnosticService.cs`
- `UsbGuard.Windows/Views/MainWindow.xaml`
- `UsbGuard.Windows/Views/MainWindow.xaml.cs`
- `UsbGuard.Windows.Tests/UsbGuard.Windows.Tests.csproj`
- `UsbGuard.Windows.Tests/TempCandidatePolicyTests.cs`

## Testes previstos

A suíte contém testes para dados pessoais, Downloads, projetos, backups, caminhos fora das raízes elegíveis, arquivos recentes, tamanho, arquivo em uso e links simbólicos/junções quando a plataforma permitir criar o fixture. Os testes usam diretórios temporários isolados e não usam dados de clientes.

## Comandos realmente executados nesta sessão

- Verificação de disponibilidade: `command -v dotnet`, `command -v wine`, `command -v x86_64-w64-mingw32-gcc`.
- Resultado: `dotnet`, Wine e MinGW não estão disponíveis; Python e Node estão disponíveis, mas não substituem o SDK .NET/host Windows.
- Validação estrutural dos arquivos foi realizada por inspeção e escrita no sandbox.

Não foram executados `dotnet restore`, `dotnet test`, `dotnet build` ou `dotnet publish`, pois o SDK .NET não existe neste ambiente. Portanto, o aplicativo Windows **não deve ser declarado compilado ou testado** nesta etapa.

## Procedimento reproduzível em Windows autorizado

```powershell
dotnet --info
dotnet restore .\USBGuard.Windows.sln
dotnet test .\UsbGuard.Windows.Tests\UsbGuard.Windows.Tests.csproj --configuration Release
dotnet build .\UsbGuard.Windows\UsbGuard.Windows.csproj --configuration Release
dotnet run --project .\UsbGuard.Windows\UsbGuard.Windows.csproj --configuration Release
dotnet publish .\UsbGuard.Windows\UsbGuard.Windows.csproj -c Release -r win-x64 --self-contained false
```

O resultado só poderá ser considerado validado após esses comandos serem executados em Windows 10/11 com .NET 8 SDK ou Visual Studio 2022 instalado.

## Limitações desta fase

A estimativa de espaço é a soma dos candidatos que passaram pelas regras; não é uma promessa de espaço recuperado. CPU é uma amostra temporal e não representa sozinha o desempenho geral. Processos, Registro e diretórios podem negar acesso; esses casos são registrados como limitações/erros. Nenhuma limpeza real foi iniciada.
