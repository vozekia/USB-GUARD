# USB Guard Windows — Fase 1

MVP Windows de diagnóstico **somente leitura**. Esta fase não exclui, move, altera, registra, desativa serviços, modifica inicialização nem coloca arquivos em quarentena.

## O que está implementado

O projeto WPF coleta informações básicas do sistema, discos, processos acessíveis, itens de inicialização consultáveis e candidatos em diretórios temporários. Cada candidato contém caminho, tamanho e justificativa. O relatório separa candidatos, itens ignorados e erros de acesso. A interface informa explicitamente que a estimativa é potencial e que uma amostra instantânea de CPU não representa todo o desempenho.

A política exige simultaneamente: raiz temporária permitida, ausência de reparse point/link/junção, arquivo regular, idade mínima de um dia e abertura somente para leitura. Pastas pessoais, Downloads, documentos, projetos, backups e perfis de navegador são protegidos. Caminhos fora das raízes permitidas são ignorados.

## Ferramentas necessárias

Em um computador Windows autorizado, instale o .NET 8 SDK ou Visual Studio 2022 com o workload de desenvolvimento desktop .NET. Não há dependências pagas.

```powershell
dotnet --info
dotnet restore .\USBGuard.Windows.sln
dotnet test .\UsbGuard.Windows.Tests\UsbGuard.Windows.Tests.csproj --configuration Release
dotnet build .\UsbGuard.Windows\UsbGuard.Windows.csproj --configuration Release
 dotnet run --project .\UsbGuard.Windows\UsbGuard.Windows.csproj --configuration Release
```

Para publicar um executável Windows x64:

```powershell
dotnet publish .\UsbGuard.Windows\UsbGuard.Windows.csproj -c Release -r win-x64 --self-contained false
```

## Estado de validação

O sandbox desta sessão não possui `dotnet`, Windows, Wine ou MinGW. Portanto, os testes e a compilação Windows **não foram executados aqui**. O código foi criado separadamente do Android, mas só deve ser declarado compilado após execução dos comandos acima em Windows.

Não usar arquivos reais de clientes nos testes. Os testes criam diretórios temporários isolados e verificam que regras de proteção, caminhos fora da raiz, arquivos recentes e arquivos em uso não viram candidatos.
