using UsbGuard.Windows.Services;

namespace UsbGuard.Windows.Tests;

public sealed class TempCandidatePolicyTests
{
    [Fact]
    public void Dados_pessoais_nunca_sao_candidatos()
    {
        using var fixture = new Fixture();
        var personal = Directory.CreateDirectory(Path.Combine(fixture.Root, "Documents"));
        var file = fixture.CreateFile(personal.FullName, "photo.jpg", "private");
        var policy = fixture.Policy();
        var result = policy.Evaluate(file.FullName, fixture.OldTime);
        Assert.False(result.IsCandidate);
        Assert.Contains("protegido", result.Reason, StringComparison.OrdinalIgnoreCase);
    }

    [Theory]
    [InlineData("Downloads")]
    [InlineData("Projects")]
    [InlineData("Backups")]
    public void Pastas_protegidas_sao_ignoradas(string folder)
    {
        using var fixture = new Fixture();
        var dir = Directory.CreateDirectory(Path.Combine(fixture.Root, folder));
        var file = fixture.CreateFile(dir.FullName, "data.bin", "client data");
        Assert.False(fixture.Policy().Evaluate(file.FullName, fixture.OldTime).IsCandidate);
    }

    [Fact]
    public void Caminho_fora_da_raiz_temporaria_nao_contorna_a_regra()
    {
        using var fixture = new Fixture();
        var outside = Directory.CreateDirectory(Path.Combine(Path.GetTempPath(), "usb-guard-outside-" + Guid.NewGuid()));
        try
        {
            var file = fixture.CreateFile(outside.FullName, "old.tmp", "x");
            var result = fixture.Policy().Evaluate(file.FullName, fixture.OldTime);
            Assert.False(result.IsCandidate);
            Assert.Contains("raízes", result.Reason, StringComparison.OrdinalIgnoreCase);
        }
        finally { outside.Delete(true); }
    }

    [Fact]
    public void Arquivo_recente_e_ignorado()
    {
        using var fixture = new Fixture();
        var file = fixture.CreateFile(fixture.Root, "recent.tmp", "x");
        var result = fixture.Policy().Evaluate(file.FullName, DateTimeOffset.UtcNow);
        Assert.False(result.IsCandidate);
    }

    [Fact]
    public void Tamanho_do_candidato_e_calculado()
    {
        using var fixture = new Fixture();
        var file = fixture.CreateFile(fixture.Root, "old.tmp", new string('a', 1234));
        var result = fixture.Policy().Evaluate(file.FullName, fixture.OldTime);
        Assert.True(result.IsCandidate);
        Assert.Equal(1234, result.SizeBytes);
    }

    [Fact]
    public void Link_simbolico_nao_e_elegivel()
    {
        using var fixture = new Fixture();
        var target = Directory.CreateDirectory(Path.Combine(Path.GetTempPath(), "usb-guard-target-" + Guid.NewGuid()));
        try
        {
            var link = Path.Combine(fixture.Root, "linked");
            try { Directory.CreateSymbolicLink(link, target.FullName); }
            catch (Exception ex) when (ex is UnauthorizedAccessException or IOException or PlatformNotSupportedException) { return; }
            var file = fixture.CreateFile(target.FullName, "outside.tmp", "outside");
            Assert.False(fixture.Policy().Evaluate(Path.Combine(link, file.Name), fixture.OldTime).IsCandidate);
        }
        finally { target.Delete(true); }
    }

    [Fact]
    public void Arquivo_em_uso_ou_inacessivel_nao_derrota_a_politica()
    {
        using var fixture = new Fixture();
        var file = fixture.CreateFile(fixture.Root, "locked.tmp", "locked");
        using var lockHandle = new FileStream(file.FullName, FileMode.Open, FileAccess.ReadWrite, FileShare.None);
        var result = fixture.Policy().Evaluate(file.FullName, fixture.OldTime);
        Assert.False(result.IsCandidate);
        Assert.Contains("uso", result.Reason, StringComparison.OrdinalIgnoreCase);
    }

    private sealed class Fixture : IDisposable
    {
        public string Root { get; } = Directory.CreateDirectory(Path.Combine(Path.GetTempPath(), "usb-guard-fixture-" + Guid.NewGuid())).FullName;
        public DateTimeOffset OldTime => DateTimeOffset.UtcNow.AddDays(-2);
        public TempCandidatePolicy Policy() => new(new[] { Root }, new[] { Path.Combine(Root, "Documents"), Path.Combine(Root, "Downloads"), Path.Combine(Root, "Projects"), Path.Combine(Root, "Backups") });
        public FileInfo CreateFile(string directory, string name, string contents)
        {
            Directory.CreateDirectory(directory);
            var path = Path.Combine(directory, name);
            File.WriteAllText(path, contents);
            File.SetLastWriteTimeUtc(path, OldTime.UtcDateTime);
            return new FileInfo(path);
        }
        public void Dispose() => new DirectoryInfo(Root).Delete(true);
    }
}
