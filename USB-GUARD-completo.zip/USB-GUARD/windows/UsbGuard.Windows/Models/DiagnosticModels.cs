namespace UsbGuard.Windows.Models;

public enum ObservationState
{
    Available,
    NotSupported,
    PermissionDenied,
    Inconclusive,
    Error
}

public sealed record SystemSnapshot(
    string OperatingSystem,
    string MachineName,
    ObservationState State,
    long TotalMemoryBytes,
    long AvailableMemoryBytes,
    double CpuUsagePercent,
    IReadOnlyList<DriveSnapshot> Drives,
    IReadOnlyList<ProcessSnapshot> Processes,
    IReadOnlyList<StartupItem> StartupItems,
    IReadOnlyList<string> Limitations);

public sealed record DriveSnapshot(string Name, long TotalBytes, long AvailableBytes, ObservationState State);
public sealed record ProcessSnapshot(int Id, string Name, long WorkingSetBytes, ObservationState State);
public sealed record StartupItem(string Source, string Name, string Command, ObservationState State);

public sealed record TempCandidate(
    string FullPath,
    long SizeBytes,
    string Reason,
    ObservationState State);

public sealed record IgnoredItem(string Path, string Reason, ObservationState State);

public sealed record DiagnosticReport(
    DateTimeOffset CollectedAt,
    SystemSnapshot System,
    IReadOnlyList<TempCandidate> Candidates,
    IReadOnlyList<IgnoredItem> IgnoredItems,
    IReadOnlyList<string> Errors)
{
    public long PotentiallyRecoverableBytes => Candidates.Sum(x => x.SizeBytes);
}
