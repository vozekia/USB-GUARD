using UsbGuard.Windows.Models;

namespace UsbGuard.Windows.Services;

public sealed class TempCandidatePolicy
{
    private static readonly TimeSpan MinimumAge = TimeSpan.FromDays(1);
    private readonly IReadOnlyList<string> _eligibleRoots;
    private readonly IReadOnlyList<string> _protectedRoots;

    public TempCandidatePolicy(IEnumerable<string>? eligibleRoots = null, IEnumerable<string>? protectedRoots = null)
    {
        _eligibleRoots = NormalizeRoots(eligibleRoots ?? GetDefaultEligibleRoots());
        _protectedRoots = NormalizeRoots(protectedRoots ?? GetDefaultProtectedRoots());
    }

    public CandidateDecision Evaluate(string path, DateTimeOffset now, FileInfo? fileInfo = null)
    {
        string fullPath;
        try { fullPath = Path.GetFullPath(path); }
        catch (Exception ex) when (ex is ArgumentException or NotSupportedException or PathTooLongException) { return CandidateDecision.Ignore("Caminho inválido: " + ex.Message); }
        if (!IsUnderAnyRoot(fullPath, _eligibleRoots)) return CandidateDecision.Ignore("Fora das raízes temporárias permitidas.");
        if (IsProtectedPath(fullPath)) return CandidateDecision.Ignore("Caminho protegido: dados pessoais ou de trabalho.");
        if (IsReparsePath(fullPath)) return CandidateDecision.Ignore("Reparse point, link simbólico ou junção não é elegível.");
        try
        {
            var info = fileInfo ?? new FileInfo(fullPath);
            if (!info.Exists) return CandidateDecision.Ignore("Arquivo inexistente ou inacessível.");
            if ((info.Attributes & FileAttributes.ReparsePoint) != 0) return CandidateDecision.Ignore("Arquivo reparse point não é elegível.");
            if (now.UtcDateTime - info.LastWriteTimeUtc < MinimumAge) return CandidateDecision.Ignore("Arquivo recente; finalidade e uso ainda não são seguros para limpeza.");
            using var stream = new FileStream(fullPath, FileMode.Open, FileAccess.Read, FileShare.Read);
            return CandidateDecision.Candidate(info.Length, "Arquivo regular em diretório temporário, antigo e legível.");
        }
        catch (UnauthorizedAccessException) { return CandidateDecision.Ignore("Acesso negado; nenhum privilégio foi solicitado."); }
        catch (IOException) { return CandidateDecision.Ignore("Arquivo em uso, inacessível ou com falha de leitura."); }
    }

    public bool IsProtectedPath(string path) => IsUnderAnyRoot(path, _protectedRoots);

    private static bool IsReparsePath(string path)
    {
        var parent = Path.GetDirectoryName(path);
        if (string.IsNullOrWhiteSpace(parent)) return true;
        var current = new DirectoryInfo(parent);
        while (current is not null)
        {
            if ((current.Attributes & FileAttributes.ReparsePoint) != 0) return true;
            current = current.Parent;
        }
        return false;
    }

    private static bool IsUnderAnyRoot(string path, IEnumerable<string> roots)
    {
        var full = Path.GetFullPath(path).TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar;
        return roots.Any(root => full.StartsWith(root, StringComparison.OrdinalIgnoreCase));
    }

    private static IReadOnlyList<string> NormalizeRoots(IEnumerable<string> roots) => roots
        .Where(x => !string.IsNullOrWhiteSpace(x))
        .Select(x => Path.GetFullPath(x).TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar)
        .Distinct(StringComparer.OrdinalIgnoreCase)
        .ToArray();

    private static IEnumerable<string> GetDefaultEligibleRoots()
    {
        yield return Path.GetTempPath();
        var windows = Environment.GetFolderPath(Environment.SpecialFolder.Windows);
        if (!string.IsNullOrWhiteSpace(windows)) yield return Path.Combine(windows, "Temp");
    }

    private static IEnumerable<string> GetDefaultProtectedRoots()
    {
        var home = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
        foreach (var root in new[]
        {
            Environment.GetFolderPath(Environment.SpecialFolder.Desktop),
            Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),
            Environment.GetFolderPath(Environment.SpecialFolder.MyPictures),
            Environment.GetFolderPath(Environment.SpecialFolder.MyVideos),
            Environment.GetFolderPath(Environment.SpecialFolder.MyMusic),
            Path.Combine(home, "Downloads"), Path.Combine(home, "OneDrive"), Path.Combine(home, "source"),
            Path.Combine(home, "Projects"), Path.Combine(home, "Backups"), Path.Combine(home, "AppData", "Roaming"),
            Path.Combine(home, "AppData", "Local", "Google", "Chrome", "User Data"),
            Path.Combine(home, "AppData", "Local", "Microsoft", "Edge", "User Data")
        }) yield return root;
    }
}

public sealed record CandidateDecision(bool IsCandidate, long SizeBytes, string Reason)
{
    public static CandidateDecision Candidate(long size, string reason) => new(true, size, reason);
    public static CandidateDecision Ignore(string reason) => new(false, 0, reason);
}
