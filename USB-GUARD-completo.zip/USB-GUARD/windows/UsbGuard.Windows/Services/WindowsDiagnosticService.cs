using System.Diagnostics;
using Microsoft.Win32;
using System.Runtime.InteropServices;
using System.Security;
using UsbGuard.Windows.Models;

namespace UsbGuard.Windows.Services;

public sealed class WindowsDiagnosticService
{
    private readonly TempCandidatePolicy _policy;

    public WindowsDiagnosticService(TempCandidatePolicy? policy = null) => _policy = policy ?? new TempCandidatePolicy();

    public DiagnosticReport Collect()
    {
        var errors = new List<string>();
        var snapshot = CollectSnapshot(errors);
        var candidates = new List<TempCandidate>();
        var ignored = new List<IgnoredItem>();
        foreach (var root in GetTempRoots())
            ScanTempRoot(root, candidates, ignored, errors);
        return new DiagnosticReport(DateTimeOffset.UtcNow, snapshot, candidates, ignored, errors);
    }

    private SystemSnapshot CollectSnapshot(List<string> errors)
    {
        var drives = DriveInfo.GetDrives().Select(d => TryDrive(d, errors)).ToList();
        var processes = Process.GetProcesses().Select(p => TryProcess(p, errors)).Where(p => p is not null).Cast<ProcessSnapshot>().ToList();
        var memory = ReadMemory();
        return new SystemSnapshot(
            Environment.OSVersion.VersionString,
            Environment.MachineName,
            ObservationState.Available,
            memory.TotalBytes,
            memory.AvailableBytes,
            EstimateCpuUsage(),
            drives,
            processes,
            ReadStartupItems(errors),
            errors.ToList());
    }

    private static IEnumerable<string> GetTempRoots()
    {
        yield return Path.GetTempPath();
        var windows = Environment.GetFolderPath(Environment.SpecialFolder.Windows);
        if (!string.IsNullOrWhiteSpace(windows)) yield return Path.Combine(windows, "Temp");
    }

    private void ScanTempRoot(string root, List<TempCandidate> candidates, List<IgnoredItem> ignored, List<string> errors)
    {
        try
        {
            if (!Directory.Exists(root) || _policy.IsProtectedPath(root)) return;
            foreach (var path in Directory.EnumerateFiles(root, "*", SearchOption.AllDirectories))
            {
                var decision = _policy.Evaluate(path, DateTimeOffset.UtcNow);
                if (decision.IsCandidate) candidates.Add(new TempCandidate(path, decision.SizeBytes, decision.Reason, ObservationState.Available));
                else ignored.Add(new IgnoredItem(path, decision.Reason, ObservationState.Inconclusive));
            }
        }
        catch (UnauthorizedAccessException ex) { errors.Add($"Acesso negado em {root}: {ex.Message}"); }
        catch (IOException ex) { errors.Add($"Falha de leitura em {root}: {ex.Message}"); }
    }

    private static DriveSnapshot TryDrive(DriveInfo drive, List<string> errors)
    {
        try { return new DriveSnapshot(drive.Name, drive.TotalSize, drive.AvailableFreeSpace, ObservationState.Available); }
        catch (Exception ex) { errors.Add($"Disco {drive.Name}: {ex.Message}"); return new DriveSnapshot(drive.Name, 0, 0, ObservationState.Error); }
    }

    private static ProcessSnapshot? TryProcess(Process process, List<string> errors)
    {
        try { return new ProcessSnapshot(process.Id, process.ProcessName, process.WorkingSet64, ObservationState.Available); }
        catch (Exception ex) when (ex is InvalidOperationException or System.ComponentModel.Win32Exception or UnauthorizedAccessException) { errors.Add($"Processo {process.Id}: {ex.Message}"); return null; }
        finally { process.Dispose(); }
    }

    private static IReadOnlyList<StartupItem> ReadStartupItems(List<string> errors)
    {
        var items = new List<StartupItem>();
        foreach (var location in new[] { (RegistryHive.CurrentUser, @"Software\Microsoft\Windows\CurrentVersion\Run"), (RegistryHive.LocalMachine, @"Software\Microsoft\Windows\CurrentVersion\Run") })
        {
            try
            {
                using var baseKey = RegistryKey.OpenBaseKey(location.Item1, RegistryView.Default);
                using var key = baseKey.OpenSubKey(location.Item2, false);
                if (key is null) continue;
                foreach (var name in key.GetValueNames()) items.Add(new StartupItem(location.Item1 + "\\" + location.Item2, name, key.GetValue(name)?.ToString() ?? "", ObservationState.Available));
            }
            catch (Exception ex) when (ex is SecurityException or UnauthorizedAccessException or IOException) { errors.Add($"Inicialização: {ex.Message}"); }
        }
        return items;
    }

    private static MemorySnapshot ReadMemory()
    {
        if (!OperatingSystem.IsWindows()) return new MemorySnapshot(0, 0);
        var status = new MemoryStatus { Length = (uint)Marshal.SizeOf<MemoryStatus>() };
        return GlobalMemoryStatusEx(ref status) ? new MemorySnapshot((long)status.TotalPhys, (long)status.AvailPhys) : new MemorySnapshot(0, 0);
    }

    private static double EstimateCpuUsage()
    {
        if (!OperatingSystem.IsWindows() || !GetSystemTimes(out var idle1, out var kernel1, out var user1)) return double.NaN;
        Thread.Sleep(250);
        if (!GetSystemTimes(out var idle2, out var kernel2, out var user2)) return double.NaN;
        var idle = ToFileTime(idle2) - ToFileTime(idle1);
        var kernel = ToFileTime(kernel2) - ToFileTime(kernel1);
        var user = ToFileTime(user2) - ToFileTime(user1);
        var total = kernel + user;
        return total <= 0 ? double.NaN : Math.Clamp((1d - idle / (double)total) * 100d, 0d, 100d);
    }

    private static ulong ToFileTime(System.Runtime.InteropServices.ComTypes.FILETIME value) => ((ulong)(uint)value.dwHighDateTime << 32) | (uint)value.dwLowDateTime;

    private sealed record MemorySnapshot(long TotalBytes, long AvailableBytes);

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    private struct MemoryStatus
    {
        public uint Length;
        public uint MemoryLoad;
        public ulong TotalPhys;
        public ulong AvailPhys;
        public ulong TotalPageFile;
        public ulong AvailPageFile;
        public ulong TotalVirtual;
        public ulong AvailVirtual;
        public ulong AvailExtendedVirtual;
    }

    [DllImport("kernel32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool GlobalMemoryStatusEx(ref MemoryStatus status);

    [DllImport("kernel32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool GetSystemTimes(out System.Runtime.InteropServices.ComTypes.FILETIME idle, out System.Runtime.InteropServices.ComTypes.FILETIME kernel, out System.Runtime.InteropServices.ComTypes.FILETIME user);
}
