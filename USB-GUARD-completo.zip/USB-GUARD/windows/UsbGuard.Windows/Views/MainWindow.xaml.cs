using System.Text;
using System.Windows;
using UsbGuard.Windows.Services;

namespace UsbGuard.Windows.Views;

public partial class MainWindow : Window
{
    private readonly WindowsDiagnosticService _service = new();

    public MainWindow() => InitializeComponent();

    private async void AnalyzeButton_Click(object sender, RoutedEventArgs e)
    {
        AnalyzeButton.IsEnabled = false;
        SummaryText.Text = "Analisando... nenhuma alteração será realizada.";
        try
        {
            var report = await Task.Run(_service.Collect);
            CandidatesGrid.ItemsSource = report.Candidates;
            SummaryText.Text = $"{report.Candidates.Count} candidato(s) somente para revisão · espaço potencial: {report.PotentiallyRecoverableBytes:N0} bytes · coleta {report.CollectedAt.LocalDateTime:G}";
            var system = new StringBuilder();
            system.AppendLine($"Sistema: {report.System.OperatingSystem}");
            system.AppendLine($"Computador: {report.System.MachineName}");
            system.AppendLine($"Memória disponível estimada: {report.System.AvailableMemoryBytes:N0} bytes de {report.System.TotalMemoryBytes:N0}");
            system.AppendLine($"CPU: {(double.IsNaN(report.System.CpuUsagePercent) ? "não calculada nesta amostra" : report.System.CpuUsagePercent + "%")}");
            system.AppendLine("\nDiscos:");
            foreach (var drive in report.System.Drives) system.AppendLine($"{drive.Name}: {drive.AvailableBytes:N0} livres de {drive.TotalBytes:N0} ({drive.State})");
            system.AppendLine($"\nProcessos acessíveis: {report.System.Processes.Count}");
            system.AppendLine($"Itens de inicialização consultados: {report.System.StartupItems.Count}");
            SystemText.Text = system.ToString();
            ErrorsText.Text = string.Join(Environment.NewLine, report.Errors.Concat(report.IgnoredItems.Take(500).Select(x => $"IGNORADO: {x.Path} — {x.Reason}")));
        }
        catch (Exception ex)
        {
            SummaryText.Text = "A análise falhou sem alterar o computador: " + ex.Message;
        }
        finally { AnalyzeButton.IsEnabled = true; }
    }
}
